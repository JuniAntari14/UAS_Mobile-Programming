package com.example.coba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class PangkatBilangan extends AppCompatActivity {
    Button btnback2;
    EditText txtbilangan;
    EditText txtpangkat;
    Button btnprosespangkat;
    EditText txthasilpangkat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pangkat_bilangan);

        btnback2 = (Button) findViewById(R.id.btnback2);
        btnprosespangkat = (Button) findViewById(R.id.btnprosespangkat);
        txtbilangan = (EditText) findViewById(R.id.txtbilangan);
        txtpangkat = (EditText) findViewById(R.id.txtpangkat);
        txthasilpangkat = (EditText) findViewById(R.id.txthasilpangkat);

        btnback2.setOnClickListener(klik_back);
        btnprosespangkat.setOnClickListener(pangkat);
    }

    View.OnClickListener klik_back = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent toPage = new Intent(PangkatBilangan.this, MainActivity.class);
            startActivity(toPage);
        }
    };

    View.OnClickListener pangkat = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int b1, b2;
            double hasil;
            b1 = Integer.parseInt(txtbilangan.getText().toString());
            b2 = Integer.parseInt(txtpangkat.getText().toString());
            hasil = Math.pow(b1, b2);
            String hasilString = b1 + "^" + b2 + " = " + hasil;
            txthasilpangkat.setText(hasilString);
        }
    };
}