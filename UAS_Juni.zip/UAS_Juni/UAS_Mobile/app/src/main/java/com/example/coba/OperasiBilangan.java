package com.example.coba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class OperasiBilangan extends AppCompatActivity {
    Button btnback1;
    EditText txtbilanganawal;
    EditText txtbilanganakhir;
    Button btntambah;
    Button btnkurang;
    Button btnkali;
    Button btnbagi;
    EditText txthasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operasi_bilangan);

        btnback1 = (Button) findViewById(R.id.btnback1);
        btntambah = (Button) findViewById(R.id.btntambah);
        btnkurang = (Button) findViewById(R.id.btnkurang);
        btnkali = (Button) findViewById(R.id.btnkali);
        btnbagi = (Button) findViewById(R.id.btnbagi);
        txtbilanganawal = (EditText) findViewById(R.id.txtbilanganawal);
        txtbilanganakhir = (EditText) findViewById(R.id.txtbilanganakhir);
        txthasil = (EditText) findViewById(R.id.txthasil);

        btnback1.setOnClickListener(klik_back);
        btntambah.setOnClickListener(tambah);
        btnkurang.setOnClickListener(kurang);
        btnkali.setOnClickListener(kali);
        btnbagi.setOnClickListener(bagi);

    }

    View.OnClickListener klik_back = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent toPage = new Intent(OperasiBilangan.this, MainActivity.class);
            startActivity(toPage);
        }
    };

    View.OnClickListener tambah = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int b1, b2, tambah;
            String hasil;
            b1 = Integer.parseInt(txtbilanganawal.getText().toString());
            b2 = Integer.parseInt(txtbilanganakhir.getText().toString());
            tambah = b1 + b2;
            hasil = b1 + " + " + b2 + " = " + tambah;
            txthasil.setText(hasil);
        }
    };

    View.OnClickListener kurang = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int b1, b2, kurang;
            String hasil;
            b1 = Integer.parseInt(txtbilanganawal.getText().toString());
            b2 = Integer.parseInt(txtbilanganakhir.getText().toString());
            kurang = b1 - b2;
            hasil = b1 + " - " + b2 + " = " + kurang;
            txthasil.setText(hasil);
        }
    };

    View.OnClickListener kali = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int b1, b2, kali;
            String hasil;
            b1 = Integer.parseInt(txtbilanganawal.getText().toString());
            b2 = Integer.parseInt(txtbilanganakhir.getText().toString());
            kali = b1 * b2;
            hasil = b1 + " * " + b2 + " = " + kali;
            txthasil.setText(hasil);
        }
    };

    View.OnClickListener bagi = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int b1, b2, bagi;
            String hasil;
            b1 = Integer.parseInt(txtbilanganawal.getText().toString());
            b2 = Integer.parseInt(txtbilanganakhir.getText().toString());
            bagi = b1 / b2;
            hasil = b1 + " / " + b2 + " = " + bagi;
            txthasil.setText(hasil);
        }
    };

}