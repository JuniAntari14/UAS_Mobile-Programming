package com.example.coba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnOperasiBilangan;
    Button btnPangkatBilangan;
    Button btnFaktorial;
    Button btnAbout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOperasiBilangan = (Button) findViewById(R.id.btnOperasiBilangan);
        btnPangkatBilangan = (Button) findViewById(R.id.btnPangkatBilangan);
        btnFaktorial = (Button) findViewById(R.id.btnFaktorial);
        btnAbout = (Button) findViewById(R.id.btnAbout);

        btnOperasiBilangan.setOnClickListener(klik_OperasiBilangan);
        btnPangkatBilangan.setOnClickListener(klik_PangkatBilangan);
        btnFaktorial.setOnClickListener(klik_Faktorial);
        btnAbout.setOnClickListener(klik_About);
    }

    View.OnClickListener klik_OperasiBilangan = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent toPage = new Intent(MainActivity.this, OperasiBilangan.class);
            startActivity(toPage);
        }
    };

    View.OnClickListener klik_PangkatBilangan = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent toPage = new Intent(MainActivity.this, PangkatBilangan.class);
            startActivity(toPage);
        }
    };

    View.OnClickListener klik_Faktorial = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent toPage = new Intent(MainActivity.this, Faktorial.class);
            startActivity(toPage);
        }
    };

    View.OnClickListener klik_About = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent toPage = new Intent(MainActivity.this, About.class);
            startActivity(toPage);
        }
    };
}