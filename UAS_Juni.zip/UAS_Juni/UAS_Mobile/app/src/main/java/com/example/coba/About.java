package com.example.coba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class About extends AppCompatActivity {
    Button btnback4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        btnback4 = (Button) findViewById(R.id.btnback4);

        btnback4.setOnClickListener(klik_back);
    }

    View.OnClickListener klik_back = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent toPage = new Intent(About.this, MainActivity.class);
            startActivity(toPage);
        }
    };
}