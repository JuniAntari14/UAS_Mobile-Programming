package com.example.coba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Faktorial extends AppCompatActivity {
    Button btnback3;
    EditText txtbilanganfaktorial;
    Button btnprosesfaktorial;
    EditText txthasilfaktorial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faktorial);

        btnback3 = (Button) findViewById(R.id.btnback3);
        btnprosesfaktorial = (Button) findViewById(R.id.btnprosesfaktorial);
        txtbilanganfaktorial = (EditText) findViewById(R.id.txtbilanganfaktorial);
        txthasilfaktorial = (EditText) findViewById(R.id.txthasilfaktorial);

        btnback3.setOnClickListener(klik_back);
        btnprosesfaktorial.setOnClickListener(faktorial);
    }

    View.OnClickListener klik_back = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent toPage = new Intent(Faktorial.this, MainActivity.class);
            startActivity(toPage);
        }
    };

    View.OnClickListener faktorial = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int n, hasil;
            n = Integer.parseInt(txtbilanganfaktorial.getText().toString());
            hasil = 1;

            for (int i = 1; i <= n; i++) {
                hasil *= i;
            }

            String hasilString = n + "! = " + hasil;
            txthasilfaktorial.setText(hasilString);
        }
    };

}